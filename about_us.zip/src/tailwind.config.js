module.exports = {
  // ... other configuration options ...
  theme: {
    fontFamily: {
      
    },
    // Other theme configurations...
  },
};
